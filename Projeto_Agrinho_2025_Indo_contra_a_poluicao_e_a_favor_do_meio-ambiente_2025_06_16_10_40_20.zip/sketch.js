let px,
  py,
  ps = 20,
  v = 2; // Posição (x, y), tamanho da pessoa, velocidade
let bx, by; // Posição da lixeira
let lixo = []; // Array para o lixo
let plantas = []; // Array para as plantas
let lx,
  ly,
  lw = 160,
  lh = 70; // Posição e dimensões do lago
let corGrama, corLago, corPessoa, corLixeira, corLixo, corRoupa, corCabelo, i;
let modoPlantio = false; // Variável para controlar o modo de plantio

function setup() {
  createCanvas(600, 400);
  px = 50;
  py = height - 50;
  bx = width - 50;
  by = height - 50;
  lx = width / 2 - 50;
  ly = height / 2 - 30;
  corGrama = color(143,218,143);
  corLago = color(153, 204, 255);
  corPessoa = color(255, 229, 204);
  corLixeira = color(192);
  corLixo = color(160);
  corRoupa = color(229, 204, 255);
  corCabelo = color(131, 113, 82);

  for (let i = 0; i < 5; i++) {
    // Menos lixo para simplificar
    lixo.push({
      x: random(20, width - 20),
      y: random(20, height - 80),
      pegou: false,
    });
  }
}

function draw() {
  background(corGrama);

  // Lago
  fill(corLago);
  ellipse(lx, ly, lw, lh);
  fill(192, 192, 192)
  ellipse()
  
   // Desenhar as plantas
  for (let p of plantas) {
    if (p.tipo === 'flor') {
      fill(255, 100, 150); // Cor de flor rosa
      ellipse(p.x, p.y, 8, 8);
      fill(50, 150, 50); // Haste da flor
      rect(p.x - 1, p.y + 4, 2, 8);
    } else if (p.tipo === 'arvore') {
      fill(100, 50, 0); // Tronco marrom
      rect(p.x - 5, p.y + 5, 10, 15);
      fill(50, 150, 50); // Folhas verdes
      ellipse(p.x, p.y, 25, 25);
    }
  }

  // Lixeira
  fill(corLixeira);
  rect(bx - 15, by - 30, 30, 30);

  // Lixo
  fill(corLixo);
  for (let l of lixo) {
    if (!l.pegou) ellipse(l.x, l.y, 15, 8);
  }

  // Pessoa
  fill(corCabelo)
  rect(px - ps / 2, py - ps / 1, ps / 1, ps / 1);
  fill(corPessoa);
  ellipse(px, py - ps / 1, ps, ps);
  fill(corRoupa)
  rect(px - ps / 4, py - ps / 2, ps / 2, ps / 2);
  fill(corCabelo)
  ellipse(px - ps / 40, py - ps / 0.8, ps / 1, ps / 1.9);
  
   // Indicar modo atual
  fill(0);
  textSize(14);
  textAlign(LEFT, TOP);
  text(`Modo: ${modoPlantio ? 'Plantio (P)' : 'Movimento (P)'}`, 10, 10);

  // Movimento
  if (keyIsDown(LEFT_ARROW)) px -= v;
  if (keyIsDown(RIGHT_ARROW)) px += v;
  if (keyIsDown(UP_ARROW)) py -= v;
  if (keyIsDown(DOWN_ARROW)) py += v;
  
   // Ação (Plantar)
  if (keyWentDown(' ')) { // Usa a barra de espaço para plantar
    if (modoPlantio) {
      let tipoPlanta = random() < 0.5 ? 'flor' : 'arvore'; // 50% de chance de ser flor ou árvore
      plantas.push({ x: px, y: py, tipo: tipoPlanta });
    }
  }

  // Trocar modo (Plantio/Movimento)
  if (keyWentDown('p') || keyWentDown('P')) { // Tecla 'P' para alternar o modo
    modoPlantio = !modoPlantio;
  }

  // Pegar lixo
  for (let l of lixo) {
    if (!l.pegou && dist(px, py, l.x, l.y) < ps / 2 + 5) {
      l.pegou = true;
    }
  }

  // Jogar lixo
  for (let i = lixo.length - 1; i >= 0; i--) {
    if (lixo[i].pegou && dist(px, py, bx, by) < ps / 2 + 15) {
      lixo.splice(i, 1);
    }
  }

  // Após limpar o parque
  if (lixo.length === 0) {
    fill(255);
    textSize(20);
    textAlign(CENTER, CENTER);
    textFont('Verdana')
    text("Você limpou o parque, parabéns! Agora você pode adicionar as plantas!", width / 2, height / 12);
  }
}
// Para usar keyWentDown (executa uma vez ao pressionar a tecla)
let keyHeld = {};
function keyPressed() {
  keyHeld[key.toLowerCase()] = true;
}
function keyReleased() {
  keyHeld[key.toLowerCase()] = false;
}
function keyWentDown(k) {
  let r = keyHeld[k.toLowerCase()];
  keyHeld[k.toLowerCase()] = false;
  return r;
}